//
//  Contacts.h
//  Boku
//
//  Created by Ghanshyam on 8/4/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AddressBook/AddressBook.h>

@class Person;

@interface Contacts : NSObject{
    
    /**
     *  Reference to Address Book Database object
     */
    ABAddressBookRef    bKAddressBook;
    
    /**
     *  Container for mutable persons record
     */
    NSMutableArray      *arrMutalbePersons;
    
    
    /**
     *  Handler which is called when AddressBook is ready to Use. this is only single handler since its SharedInstance . this block hold strong reference of current context if passed block is having global variable . so make sure to make passed block as nil , when ever context is no longer in use else it will make leak.
     */
    void (^AddressBookReadyToUseHandler)(void);
}


/**
 *  Boolean identifier which says Exteranl changes for Addressbook
 */
@property (nonatomic,assign)    bool    isHavingExternalChanges;

/**
 *  Used to get shared Contact Shared Instance
 *
 *  @return : Shared Contact Instance
 */
//+(id)sharedInstance;
+(Contacts *)sharedInstance;

/**
 *  Used to identify whether particular recordID record is already existing or not
 *
 *  @param recordId    : Centralized recordID
 *  @param peopleArray : Persons Container array
 *  @param person      : person object address which can be referenced later
 *
 *  @return :  YES if record is already existing or NO if record is not existing
 */
- (BOOL)isRecordExisting:(NSNumber *)recordId peopleArray:(NSArray *)peopleArray WithPerson:(Person *__autoreleasing *)person;



/**
 *  Used to sync all person contact from centralized AddressBook DB
 *
 *  @param addressBook : Reference to shared Centralized
 */
-(void)BKContactsWithAddressBook;


/**
 *  Used to provide shared contacts array container
 *
 *  @param arrContacts : weak reference contacts array container Address
 */
-(void)sharedContactsWeakReference:(NSMutableArray *__autoreleasing *)arrContacts;


/**
 *  Used to update or provide block handler , which will be called when ever AddressBook is ready to use
 *
 *  @param handler : Block handler which will be called
 */
-(void)setAdderssBookHandler:(void(^)(void))handler;


/**
 *  Used to sync Boku Contacts detail with local contacts detail
 *
 *  @param arrBokuContacts : Boku Contacts array container
 */
-(void)syncLocalContactsWithBokuContacts:(NSArray *)arrBokuContacts;

/**
 *  Used to remove specific Contact from Contacts Container
 *
 *  @param contactNo : Contact No which is to be removed
 */
-(void)removeContact:(NSString *)contactNo;


@end
