//
//  Contacts.m
//  Boku
//
//  Created by Ghanshyam on 8/4/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import "Contacts.h"
#import "Person.h"

@implementation Contacts

/**
 *  Shared Contact Instance
 */
static  Contacts    *sharedInstance;


#pragma mark - Class Methods
/**
 *  Used to get shared Contact Shared Instance
 *
 *  @return : Shared Contact Instance
 */
+(Contacts *)sharedInstance
{
    //static Contacts *sharedInstance = nil;
    
    @synchronized(self)
    {
        if (sharedInstance == nil)
        {
            sharedInstance = [[Contacts alloc] init];
        }
    }
    return sharedInstance;
}


#pragma mark - Super Class Methods
- (id)init
{
    NSLog(@"INIT AGAIN");
    if ((self = [super init]))
    {
        //Mutalbe container initialization & allocation
        arrMutalbePersons = [[NSMutableArray alloc] init];
        
        CFErrorRef *error = nil;
        
        bKAddressBook = ABAddressBookCreateWithOptions(NULL, error);
        //people = nil;
        //   APPDELEGATE.isCallBackCalled = NO;
        //   [self refresh];
        dispatch_sync(dispatch_get_main_queue(), ^{
            ABAddressBookRegisterExternalChangeCallback (bKAddressBook,
                                                         MyAddressBookExternalChangeCallback,
                                                         (__bridge void *)(self)
                                                         );
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(processingContactsBeingActive) name:UIApplicationDidBecomeActiveNotification object:nil];
        });
    }
    return self;
}


-(void)dealloc{
    
    NSLog(@"contacts dealloc");
    
    if (bKAddressBook) {
        //UnRegistering AddressBook with shared Address Book Database
        ABAddressBookUnregisterExternalChangeCallback(bKAddressBook, MyAddressBookExternalChangeCallback, (__bridge void *)(self));
    }
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark - Instance Methods
-(void)processingContactsBeingActive{
    NSLog(@"processingContactsBeingActive");
    
    if (self.isHavingExternalChanges) {
        //here we received changes in centralized Address Book Core data , so we fetch those again with new AddressBook reference
        dispatch_queue_t addressQueue = dispatch_queue_create("CONTACTS_DISPATCH", NULL);
        dispatch_async(addressQueue, ^{
            [[Contacts sharedInstance] BKContactsWithAddressBook];
        });
        
        //Showing loader
        AppDelegate *appdelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
        [appdelegate.loader show];
    }
}


/**
 *  Used to provide shared contacts array container
 *
 *  @param arrContacts : weak reference contacts array container Address
 */
-(void)sharedContactsWeakReference:(NSMutableArray *__autoreleasing *)arrContacts{
    
    //Before passing weak reference to any context we assing YES to isFilterd in all Person Object
    [arrMutalbePersons makeObjectsPerformSelector:NSSelectorFromString(@"setFilterValue:") withObject:[NSNumber numberWithBool:YES]];
    
    //passing NO to isSelected in all Person Object
    [arrMutalbePersons makeObjectsPerformSelector:NSSelectorFromString(@"setSelectionValue:") withObject:[NSNumber numberWithBool:NO]];
    
    *arrContacts = arrMutalbePersons;
}

/**
 *  Used to update or provide block handler , which will be called when ever AddressBook is ready to use . make sure that this block is to be set nil when block assigning context is no longer in use. since block keep strong reference to passing context if block itself consist global context reference.
 *
 *  @param handler : Block handler which will be called
 */
-(void)setAdderssBookHandler:(void(^)(void))handler{
    AddressBookReadyToUseHandler = handler;
}

/**
 *  Used to remove non process contacts
 */
-(void)removeNonProcessedPersons{
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF.isProcessed == %@",[NSNumber numberWithBool:NO]];
    NSArray *arrDeletingPersons = [arrMutalbePersons filteredArrayUsingPredicate:predicate];
    
    if (arrDeletingPersons.count) {
        //we have some persons in mutable container those are no longer part of centralized DB , we have to remove those persons
        [arrMutalbePersons removeObjectsInArray:arrDeletingPersons];
    }
}

/**
 *  Used to sort Contacts array alphabeticallly
 */

-(void)sortContactsAlphabetically{
    //Sorting Contacts alphabetically
    NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"displayName" ascending:YES];
    NSArray *arrSortedDescriptor = @[sortDescriptor];
    [arrMutalbePersons sortUsingDescriptors:arrSortedDescriptor];
}

/**
 *  Used to identify whether particular recordID record is already existing or not
 *
 *  @param recordId    : Centralized recordID
 *  @param peopleArray : Persons Container array
 *  @param person      : person object address which can be referenced later
 *
 *  @return :  YES if record is already existing or NO if record is not existing
 */
- (BOOL)isRecordExisting:(NSNumber *)recordId peopleArray:(NSArray *)peopleArray WithPerson:(Person *__autoreleasing *)person
{
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"recordID == %@", recordId];
    NSArray *duplicates = [peopleArray filteredArrayUsingPredicate:predicate];
    if (duplicates.count) {
        *person = (Person *)[duplicates objectAtIndex:0];
    }
    return (duplicates.count>0?YES:NO);
}


/**
 *  Used to sync all person contact from centralized AddressBook DB
 *
 *  @param addressBook : Reference to shared Centralized
 */
-(void)BKContactsWithAddressBook{
    
    
    UIApplicationState state = [[UIApplication sharedApplication] applicationState];
    
    if (state == UIApplicationStateBackground) {
        NSLog(@"UIApplicationStateBackground");
    }else if (state == UIApplicationStateActive){
        NSLog(@"UIApplicationStateActive");
    }else if (state == UIApplicationStateInactive){
        NSLog(@"UIApplicationStateInactive");
    }
    
    
    
    
    if (bKAddressBook) {
        ABAddressBookRevert(bKAddressBook);
    }
    
    
    CFArrayRef peopleFromAddressBook = ABAddressBookCopyArrayOfAllPeople(bKAddressBook);
    
    CFIndex numberOfPeople = ABAddressBookGetPersonCount(bKAddressBook);
 
    NSArray *arrPersonModelProperties = [CommonFunctions getModelPropertiesToArray:[Person class]];
    
    
    //Initially we are making all Person object in Mutalbe Container as NOT PROCESSED, so later any record which is existing as NOT PROCESSED can be deleted .
    [arrMutalbePersons makeObjectsPerformSelector:NSSelectorFromString(@"setProcessed:") withObject:[NSNumber numberWithBool:NO]];
    
    NSLog(@"person count is %ld",numberOfPeople);
    
    for (int personCount = 0;personCount<numberOfPeople; personCount++) {
        
        //AddressBook particular record
        ABRecordRef personRecord = CFArrayGetValueAtIndex(peopleFromAddressBook, personCount);
        
        if (ABRecordGetRecordType(personRecord) == kABPersonType) {
            //We are processing only person type records , ignoring other type like group , source
            
            ABRecordID  recordID = ABRecordGetRecordID(personRecord);
            if (recordID != kABRecordInvalidID) {
                //We have valid saved record in Centralized DB
                
                NSNumber    *personID = [NSNumber numberWithInt:recordID];
                Person *person;
                if ([self isRecordExisting:personID peopleArray:arrMutalbePersons WithPerson:&person]) {
                    
                }else{
                    person = [[Person alloc] init];
                    
                    person.recordID = personID;
                    //[arrMutalbePersons addObject:person];
                }
                
                //First Name
                if (ABRecordCopyValue(personRecord, kABPersonFirstNameProperty)) {
                    person.firstName = (__bridge NSString *)(ABRecordCopyValue(personRecord, kABPersonFirstNameProperty));
                }
                
                //Last Name
                if (ABRecordCopyValue(personRecord, kABPersonLastNameProperty)) {
                    person.lastName = (__bridge NSString *)(ABRecordCopyValue(personRecord, kABPersonLastNameProperty));
                }
                
                //Company
                if (ABRecordCopyValue(personRecord, kABPersonOrganizationProperty)) {
                    person.company = (__bridge NSString*)ABRecordCopyValue(personRecord, kABPersonOrganizationProperty);
                }
                
                
                //Birthday
                if (ABRecordCopyValue(personRecord, kABPersonBirthdayProperty)) {
                    person.birthDay = (__bridge NSDate *)ABRecordCopyValue(personRecord, kABPersonBirthdayProperty);
                }
                
                
                //Image
                if (ABPersonCopyImageData(personRecord)) {
                    NSData  *imgData = (__bridge NSData *)ABPersonCopyImageData(personRecord);
                    UIImage  *img = [UIImage imageWithData:imgData];
                    person.photo = img;
                }
                
                
                
                
                //Address
                ABMultiValueRef address = ABRecordCopyValue(personRecord, kABPersonAddressProperty);
                if (ABMultiValueGetCount(address) > 0) {
                    CFDictionaryRef dict = ABMultiValueCopyValueAtIndex(address, 0);
                    //Street
                    if (CFDictionaryGetValue(dict, kABPersonAddressStreetKey)) {
                        person.street = (__bridge NSString *)(CFDictionaryGetValue(dict, kABPersonAddressStreetKey));
                    }
                    
                    //City
                    if (CFDictionaryGetValue(dict, kABPersonAddressCityKey)) {
                        person.city = (__bridge NSString *)(CFDictionaryGetValue(dict, kABPersonAddressCityKey));
                    }
                    
                    //State
                    if (CFDictionaryGetValue(dict, kABPersonAddressStateKey)) {
                        person.state = (__bridge NSString *)(CFDictionaryGetValue(dict, kABPersonAddressStateKey));
                    }
                    
                    //Country
                    if (CFDictionaryGetValue(dict, kABPersonAddressCountryKey)) {
                        person.country = (__bridge NSString *)(CFDictionaryGetValue(dict, kABPersonAddressCountryKey));
                    }
                    
                    //CountryCode
                    if (CFDictionaryGetValue(dict, kABPersonAddressCountryCodeKey)) {
                        person.countryCode = (__bridge NSString *)(CFDictionaryGetValue(dict, kABPersonAddressCountryCodeKey));
                    }
                    
                    //ZipCode
                    if (CFDictionaryGetValue(dict, kABPersonAddressZIPKey)) {
                        person.zipCode = (__bridge NSString *)(CFDictionaryGetValue(dict, kABPersonAddressZIPKey));
                    }
                    
                    if (dict) {
                        CFRelease(dict);
                    }
                    
                }
                
                
                //Phones
                ABMultiValueRef phones = ABRecordCopyValue(personRecord, kABPersonPhoneProperty);
                for(CFIndex j = 0; j < ABMultiValueGetCount(phones); j++)
                {
                    CFStringRef phoneNumberRef = ABMultiValueCopyValueAtIndex(phones, j);
                    CFStringRef locLabel = ABMultiValueCopyLabelAtIndex(phones, j);
                    NSString *phoneLabel =(__bridge NSString*) ABAddressBookCopyLocalizedLabel(locLabel);
                    NSString *phoneNumber = (__bridge NSString *)phoneNumberRef;
                    
                    
                    
                    if (phoneNumberRef) {
                        CFRelease(phoneNumberRef);
                    }
                    if (locLabel) {
                        CFRelease(locLabel);
                    }
                    
                    //NSLog(@"  - %@ (%@)", phoneNumber, phoneLabel);
                    
                    if ([arrPersonModelProperties containsObject:[phoneLabel stringByAppendingString:@"Contact"]]) {
                        [person setValue:phoneNumber forKey:[phoneLabel stringByAppendingString:@"Contact"]];
                    }
                }
                
                
                //Emails
                ABMultiValueRef emails = ABRecordCopyValue(personRecord, kABPersonEmailProperty);
                for (CFIndex count = 0; count<ABMultiValueGetCount(emails); count++) {
                    CFStringRef emailRef = ABMultiValueCopyValueAtIndex(emails, count);
                    CFStringRef locLabel = ABMultiValueCopyLabelAtIndex(emails, count);
                    NSString *emailLabel =(__bridge NSString*) ABAddressBookCopyLocalizedLabel(locLabel);
                    NSString *email = (__bridge NSString *)emailRef;
                    if (emailRef) {
                        CFRelease(emailRef);
                    }
                    if (locLabel) {
                        CFRelease(locLabel);
                    }
                    
                    //NSLog(@"  - %@ (%@)", email, emailLabel);
                    
                    if ([arrPersonModelProperties containsObject:[emailLabel stringByAppendingString:@"Email"]]) {
                        [person setValue:email forKey:[emailLabel stringByAppendingString:@"Email"]];
                    }
                    
                }
                
                
                if (emails) {
                    CFRelease(emails);
                }
                
                if (phones) {
                    CFRelease(phones);
                }
               
                if ([person isHavingBokuContact] && ![arrMutalbePersons containsObject:person]) {
                    [arrMutalbePersons addObject:person];
                }
                
                //Used to define Person display name & boku contact no basis on address data
                [person setPersonDisplayNameAndBokuContactNo];
                
                //NSLog(@"person name is %@",person.firstName);
                
            }
            
        }
        
    }
    
    NSLog(@"total correct record %ld",(unsigned long)arrMutalbePersons.count);
    //Removing non processed Person , these are those Person which may have been deleted which were already existign
    [self removeNonProcessedPersons];
    
    
    [self sortContactsAlphabetically];
    
    
    dispatch_sync(dispatch_get_main_queue(), ^{
        if (AddressBookReadyToUseHandler) {
            AddressBookReadyToUseHandler();
        }
        
        //Showing loader
        AppDelegate *appdelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
        //Hide Loader
        [appdelegate.loader hide];
    });
    
    
    
}

/**
 *  Used to sync Boku Contacts detail with local contacts detail
 *
 *  @param arrBokuContacts : Boku Contacts array container
 */
-(void)syncLocalContactsWithBokuContacts:(NSArray *)arrBokuContacts{
    
    for (NSDictionary *dictBokuContact in arrBokuContacts) {
        
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF.bokuFormatedPhoneNo CONTAINS[cd] %@",[dictBokuContact objectForKey:@"formatted_phone_number"]];
        NSArray *arrBokuContact = [arrMutalbePersons filteredArrayUsingPredicate:predicate];
        if (arrBokuContact.count>0) {
            
            Person *person = [arrBokuContact objectAtIndex:0];
            person.bokuProfilePicURL = [dictBokuContact objectForKey:@"profile_pic"];
            person.bokuUserID = [dictBokuContact objectForKey:@"user_id"];
            person.bokuUserName = [dictBokuContact objectForKey:@"username"];
            person.is_boku_user = YES;
        }
        
    }
}


/**
 *  Used to remove specific Contact from Contacts Container
 *
 *  @param contactNo : Contact No which is to be removed
 */
-(void)removeContact:(NSString *)contactNo{
    NSString *removingContactNo = [CommonFunctions removeSpecialCharectorsOtherThenNumericFromString:contactNo];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF.bokuFormatedPhoneNo CONTAINS[cd] %@",removingContactNo];
    NSArray *arrRemovingContact = [arrMutalbePersons filteredArrayUsingPredicate:predicate];
    if (arrRemovingContact.count>0) {
        Person *person = [arrRemovingContact objectAtIndex:0];
        [arrMutalbePersons removeObject:person];
        
        if (AddressBookReadyToUseHandler) {
            AddressBookReadyToUseHandler();
        }
    }
    
    
}

#pragma mark - Blocks & Functions
/**
 *  Function which is called on external changes in AddressBook
 *
 *  @param addressBook : AddressBook which is to be reflected with changes
 *  @param info        : info about AddressBook
 *  @param context     : Context reference
 */
void MyAddressBookExternalChangeCallback(ABAddressBookRef addressBook, CFDictionaryRef info, void *context){
    Contacts *contact = (__bridge Contacts *)context;
    contact.isHavingExternalChanges = YES;
    
    NSLog(@"changes getting");
};



/*
 Concern
 
 1) when ever we are on contact list and any address book name is updated then we have to update that name in that context or same in entire App.
 
 
 2) when ever any address itme is deleted from centralized DB , then that relevant activity for that contact should be deleted in entire App.
 
 
 3) we have phone no iPhone, mobile , work , home , main . which to be considered as BokuPhoneNo.
 
    Cases
 
    >>if considered phone no is removed and other contact no is existing then its to be treated as deletion of contact, since considered phone was boku_user and that phone is no longer existing.
 
*/

@end
