//
//  Person.h
//  Boku
//
//  Created by Ghanshyam on 8/5/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Person : NSObject

/**
 *  Person global recordID
 */
@property (nonatomic,strong)    NSNumber               *recordID;


/**
 *  Persons first name
 */
@property (nonatomic,strong)    NSString               *firstName;

/**
 *  Person last name
 */
@property (nonatomic,strong)    NSString               *lastName;

/**
 *  Person full name
 */
@property(nonatomic,strong)     NSString               *displayName;


/**
 *  Person company name
 */
@property(nonatomic,strong)     NSString                 *company;

/**
 *  Person birth day
 */
@property(nonatomic,strong)     NSDate                 *birthDay;


/**
 *  Person city
 */
@property (nonatomic,strong)    NSString                *street;

/**
 *  Person city
 */
@property (nonatomic,strong)    NSString                *city;

/**
 *  Person city
 */
@property (nonatomic,strong)    NSString                *state;

/**
 *  Person city
 */
@property (nonatomic,strong)    NSString                *country;

/**
 *  Person city
 */
@property (nonatomic,strong)    NSString                *countryCode;

/**
 *  Person address container
 */
@property (nonatomic,strong)    NSMutableDictionary    *address;

/**
 *  Person address zipcode
 */
@property (nonatomic,strong)    NSString                *zipCode;




/**
 *  Person home email address
 */
@property (nonatomic,strong)    NSString                *homeEmail;

/**
 *  Person work email address
 */
@property (nonatomic,strong)    NSString                *workEmail;

/**
 *  Person work email address
 */
@property (nonatomic,strong)    NSString                *iCloudEmail;

/**
 *  Person iPhone book phone no
 */
@property (nonatomic,strong)    NSString                *iPhoneContact;

/**
 *  Person home contact number
 */
@property (nonatomic,strong)    NSString                *homeContact;

/**
 *  Person mobile contact number
 */
@property (nonatomic,strong)    NSString                *mobileContact;

/**
 *  Person work phone number
 */
@property (nonatomic,strong)    NSString                *workContact;

/**
 *  Person main phone number
 */
@property (nonatomic,strong)    NSString                *mainContact;

/**
 *  Person photo
 */
@property (nonatomic,strong)    UIImage                *photo;

/**
 *  Boolean identifier to decide whether Person is boku user
 */
@property (nonatomic, assign)   BOOL                   is_boku_user;

/**
 *  Boku App Phone no , basis on this App will work
 */
@property (nonatomic, weak)     NSString               *bokuPhoneNo;

/**
 *  Boku Formatted phone no
 */
@property (nonatomic,strong)    NSString                *bokuFormatedPhoneNo;


/**
 *  User Profile pic url , which is on boku app uploaded
 */
@property (nonatomic,strong)    NSString                *bokuProfilePicURL;

/**
 *  Boku UserID
 */
@property (nonatomic,strong)    NSString                *bokuUserID;

/**
 *  Boku UserName
 */
@property (nonatomic,strong)    NSString                *bokuUserName;


/**
 *  Put the content which is to be used in search criteria like "first_name last_name"
 */
@property (nonatomic,strong)    NSString            *firstSearch;

/**
 *  Put the content which is to be used in search criteria like "91-8386837120"
 */
@property (nonatomic,strong)    NSString            *secondSearch;

/**
 *  Put the content which is to be used in search criteria like "boku-status"
 */
@property (nonatomic,strong)    NSString            *thirdSearch;


/**
 *  Boolean identifier used while syncing record with Centralized Address Book DB.
 */
@property (nonatomic,assign)    BOOL                isProcessed;


/**
 *  Boolean identifier used to know whether this Person is in functioing due to search criteria . make isFiltered to YES when some one ask weakReference of Contacts array container
 */
@property (nonatomic,assign)    BOOL                isFiltered;


/**
 *  Boolean identifier used to know whether this Person is selected in function due to selection .
 */
@property (nonatomic,assign)    BOOL                isSelected;

/**
 *  Used to set Display name for Person FirstName,LastName/Company/Contact and bokuContactNo
 */
-(void)setPersonDisplayNameAndBokuContactNo;


/**
 *  Used to set YES/NO basis on search criteria
 *
 *  @param filterValue : YES when currenct context get filter in Search Criteria or NO when current context not in Search Criteria
 */
-(void)setFilterValue:(NSNumber *)filterValue;


/**
 *  Used to set YES/NO basis on selection criteria
 *
 *  @param filterValue : YES when currenct context get selected or NO when current context not selected
 */
-(void)setSelectionValue:(NSNumber *)selectionValue;

/**
 *  Used to decide whether Contact having any BokuContactNo or not
 *
 *  @return YES if having valid boku contact , NO if not having boku contact
 */
-(BOOL)isHavingBokuContact;


@end
