//
//  Person.m
//  Boku
//
//  Created by Ghanshyam on 8/5/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import "Person.h"

@implementation Person

#pragma mark - Instance Methods

/**
 *  Used to decide whether Contact having any BokuContactNo or not
 *
 *  @return YES if having valid boku contact , NO if not having boku contact
 */
-(BOOL)isHavingBokuContact{
    
    //Processing for BokuPhoneNO our priority is iPhone > mobile > main > home >work
    if (_iPhoneContact) {
        _bokuPhoneNo = _iPhoneContact;
        _bokuFormatedPhoneNo = [CommonFunctions removeSpecialCharectorsOtherThenNumericFromString:_bokuPhoneNo];
        return YES;
    }else if (_mobileContact){
        _bokuPhoneNo = _mobileContact;
        _bokuFormatedPhoneNo = [CommonFunctions removeSpecialCharectorsOtherThenNumericFromString:_bokuPhoneNo];
        return YES;
    }else if (_mainContact){
        _bokuPhoneNo = _mainContact;
        _bokuFormatedPhoneNo = [CommonFunctions removeSpecialCharectorsOtherThenNumericFromString:_bokuPhoneNo];
        return YES;
    }else if (_homeContact){
        _bokuPhoneNo = _homeContact;
        _bokuFormatedPhoneNo = [CommonFunctions removeSpecialCharectorsOtherThenNumericFromString:_bokuPhoneNo];
        return YES;
    }else if (_workContact){
        _bokuPhoneNo = _workContact;
        _bokuFormatedPhoneNo = [CommonFunctions removeSpecialCharectorsOtherThenNumericFromString:_bokuPhoneNo];
        return YES;
    }
    return NO;
}

/**
 *  Used to set Display name for Person FirstName,LastName/Company/Contact and bokuContactNo
 */
-(void)setPersonDisplayNameAndBokuContactNo{
    
    //making isProcessed flag to YES
    _isProcessed    = YES;
    
    //Defining DisplayName
    if (_firstName && [_firstName stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]].length>0 &&
       _lastName && [_lastName stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]].length>0) {
        _displayName = [NSString stringWithFormat:@"%@ %@",_firstName,_lastName];
    }else if (_firstName && [_firstName stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]].length>0){
        _displayName = _firstName;
    }else if (_lastName && [_lastName stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]].length>0){
        _displayName = _lastName;
    }else if (_company && [_company stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]].length>0){
        _displayName = _company;
    }else{
        _displayName = [CommonFunctions removeSpecialCharectorsOtherThenNumericFromString:_bokuPhoneNo];
    }
    
    
    NSLog(@"_display Name = %@",_displayName);
    NSLog(@"_bokuNumber = %@",_bokuPhoneNo);
    
    //First Search Content is display name , what ever it is
    _firstSearch = _displayName;
    
    //Second search is boku flated phone no
    _secondSearch = [CommonFunctions removeSpecialCharectorsOtherThenNumericFromString:_bokuPhoneNo];
    
    //Its Company
    _thirdSearch = _company;
    
}

/**
 *  Used to say whether contact is processd for current AddressBook Centralized DB update or Add operation
 *
 *  @param processValue : YES if current context is recently created or get processed in updation of Centralized DB , NO if current context is not processed entirely .
 */
-(void)setProcessed:(NSNumber *)processValue{
    //0 : Not Processed
    //1 : Processed
    _isProcessed = [processValue intValue];
}


/**
 *  Used to set YES/NO basis on search criteria
 *
 *  @param filterValue : YES when currenct context get filter in Search Criteria or NO when current context not in Search Criteria
 */
-(void)setFilterValue:(NSNumber *)filterValue{
    _isFiltered = [filterValue intValue];
    
}

/**
 *  Used to set YES/NO basis on selection criteria
 *
 *  @param filterValue : YES when currenct context get selected or NO when current context not selected
 */
-(void)setSelectionValue:(NSNumber *)selectionValue{
    _isSelected = [selectionValue intValue];
}


@end
